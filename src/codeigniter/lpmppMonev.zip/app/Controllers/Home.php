<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        echo "This is the Home controller.";
    }
}
